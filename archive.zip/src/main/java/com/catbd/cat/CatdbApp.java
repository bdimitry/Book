package com.catbd.cat;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CatdbApp {

    public static void main(String[] args) {

        SpringApplication.run(CatdbApp.class, args);
    }

}
