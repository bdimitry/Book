SET search_path TO cats;

INSERT INTO cats.cat (name, age, weight)
VALUES ('Tom', 3, 4);

INSERT INTO cats.cat (name, age, weight)
VALUES ('Jerry', 4, 5);